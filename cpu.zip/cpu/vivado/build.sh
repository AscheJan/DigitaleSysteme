#!/bin/bash
V=2018.2
B=`getconf LONG_BIT`
ECHIP=/usr/local/echip
# ECHIP=/vol/repl331-vol2/echip
source $ECHIP/Xilinx-Vivado/Vivado/${V}/settings${B}.sh
export LM_LICENSE_FILE="2100@ti-license"
export SWT_GTK3=0
echo $LM_LICENSE_FILE 
echo source build.tcl | vivado -mode tcl

