#!/bin/bash
rm -f *.dcp
make -C ../c
./build.sh
