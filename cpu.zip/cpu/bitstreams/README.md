./bitstreams - the target location for the ./vivado/build.tcl script
