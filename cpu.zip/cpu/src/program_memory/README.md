./src/program_memory - HDL Files that contain the program memory and RAM contents.

- README.md - This file
- program_memory.vhd - Empty 4kB ROM component
- ram_memory.vhd - Empty 4kB RAM component
- program_memory_test.vhd - ROM generated from ../c/test.c using the gen_mem.sh script
- ram_memory_test.vhd - RAM generated from ../c/test.c using the gen_mem.sh script
