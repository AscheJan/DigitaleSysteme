src/systems - Complete systems (CPU, bus and perhiperals)

Files in this directory are:

- top_level.vhd - A system with a serial port, 4kB RAM and 4kB ROM. Used during testing
- top_level_expanded.vhd - An expanded system, with serial, 16-bit GPIO, 4kB RAM and 4kB ROM.
