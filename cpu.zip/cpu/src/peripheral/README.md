src/perhierals - Various things that can be hung off of the CPU bus

- README.md - This file
- peripheral_gpio.vhd - A GPIO port
- peripheral_millis.vhd	- A millisecond counter peripheral
- peripheral_ram.vhd	- A sample RAM block 
- peripheral_serial - A serial port
