./src/boards/zedboard - Board specific top level designs, and constraints

- zedboard.xdc - Constriants for a system with Serial and LEDs.
- zedboard_top_level.vhd - HDL for top level with serial and GPIO.
