./src/boards/basys3 - Board specific top level designs, and constraints

- basys3.xdc - Constriants for a system with Serial and LEDs.
- basys3_top_level.vhd - HDL for top level with serial and GPIO.
- cmod_a7.xdc -  Constriants for a system with just serial (not used)
