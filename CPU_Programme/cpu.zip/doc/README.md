./doc - documentation for the Rudi-RV32I project

Files in this directory:

* Rudi-RV32I.pdf - The structure diagram for the CPU
* System_diagram.pdf - The structure of a useful system.
